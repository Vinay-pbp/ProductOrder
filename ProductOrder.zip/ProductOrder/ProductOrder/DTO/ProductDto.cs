﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.DTO
{
    public class ProductDto
    {
        public Guid ProductId { get; set; }

        [Required(ErrorMessage ="Product code is required")]
        [RegularExpression("^[0 - 9][0 - 9][aA - zZ]{12}$", ErrorMessage = "The product code must have 12chars with first and second char alphanumeric, the other chars should be numbers.")]
        public string ProductCode { get; set; }
        [Required]
        public string ProductLabel { get; set; }
        [Required]
        public string ProductDescription { get; set; }
        public string SKU { get; set; }
        [Required]
        public decimal ProductUnitaryPrice { get; set; }
    }
}
