﻿using ProductOrder.DTO;
using ProductOrder.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Interface
{
    public interface IProductService
    {
        Task<ProductSaveResponse> SaveProductDetailAsync(ProductDto productDto);
        Task<List<ProductGetResponse>> GetAllProductAsync();
        Task<ProductUpdateResponse> UpdateProductAsync(string ProductId, ProductUpdateDto productCodeUpdateDto);
    }
}
