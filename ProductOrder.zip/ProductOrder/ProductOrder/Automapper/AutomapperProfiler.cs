﻿using AutoMapper;
using ProductOrder.DTO;
using ProductOrder.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Automapper
{
    public class AutomapperProfiler: Profile
    {
        public AutomapperProfiler()
        {
            CreateMap<ProductDto, Product>()
            .ForMember(dest => dest.ProductId, opt => opt.MapFrom(_ => new Guid()))
            .ForMember(dest => dest.CreationTime, opt => opt.MapFrom(_ => DateTime.UtcNow));

        }
    }
}
