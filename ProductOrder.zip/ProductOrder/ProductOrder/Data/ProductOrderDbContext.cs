﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ProductOrder.Models.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Data
{
    public class ProductOrderDbContext: DbContext
    {
        private IConfiguration Configuration { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        public ProductOrderDbContext()
        {
        }

        public ProductOrderDbContext(DbContextOptions<ProductOrderDbContext> options)
            : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite(FetchDbConnectionString());
            }
        }

        private string FetchDbConnectionString()
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", true, false)
                .Build();

            return Configuration.GetValue<string>("DbConnectionString");
        }
    }
}
