﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using ProductOrder.Data;
using ProductOrder.DTO;
using ProductOrder.Interface;
using ProductOrder.Models.Entities;
using ProductOrder.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using static ProductOrder.Startup;
using Product = ProductOrder.Models.Entities.Product;

namespace ProductOrder.Service
{
    public class ProductService : IProductService
    {
		private readonly ProductOrderDbContext _context;
		private readonly ILogger<Product> _logger;
		private readonly IMapper _mapper;

		public ProductService(ProductOrderDbContext context, ILogger<Product> logger, IMapper mapper)
		{
			_context = context;
			_logger = logger;
			_mapper = mapper;
		}

		public async Task<List<ProductGetResponse>> GetAllProductAsync()
		{
			try
			{
				var response = (_context.Products.ToList());
				return response?.Count > 0 ? _mapper.Map<List<ProductGetResponse>>(response) : null;
			}
			catch (Exception ex)
			{
				_logger.LogError(ex.InnerException == null ? ex.Message : ex.InnerException.Message);
				throw;
			}
		}

		public async Task<ProductSaveResponse> SaveProductDetailAsync(ProductDto productDto)
        {
			try
			{
				Product product =_mapper.Map<Product>(productDto);
				_context.Add(product);
				var SaveResponse=await _context.SaveChangesAsync().ConfigureAwait(false);
				return new ProductSaveResponse()
				{
					ProductId = productDto.ProductId.ToString(),
					SystemMessage = SaveResponse > 0 ? "Product Added Successfully" : "Failed to add Product!!"
				};

			}
			catch (Exception ex)
			{
				_logger.LogInformation("Product not saved in DB: " + productDto.ProductCode);
				_logger.LogError(ex.InnerException == null ? ex.Message : ex.InnerException.Message);
				throw;
			}
        }

		public async Task<ProductUpdateResponse> UpdateProductAsync(string ProductId, ProductUpdateDto productUpdateDto)
		{
			try
			{
				Product product = new Product();
				var result = _context.Products.Find(ProductId);
				if (result == null)
					return null;
				else
				{
					product = result;
				}

				product.ProductCode = productUpdateDto.ProductCode;
				product.ProductDescription = productUpdateDto.ProductDescription;
				product.ProductLabel = productUpdateDto.ProductLabel;
				product.ProductUnitaryPrice = productUpdateDto.ProductUnitaryPrice;
				product.SKU = productUpdateDto.SKU;
				product.LastUpdateTime = DateTime.UtcNow;
				var response = _context.Update(product);
				return new ProductUpdateResponse()
				{
					SystemMessage = response != null ? "Product updated successfully" : "Failed to update Product",
					ProductId = product.ProductId
				};
			}
			catch (Exception ex)
			{
				_logger.LogError(ex.InnerException == null ? ex.Message : ex.InnerException.Message);
				throw;
			}
		}
	}
}
