﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models
{
    public class Product
    {
        public Guid ProductId { get; set; }

        [Required]
        public string ProductCode { get; set; }
        [Required]
        public string ProductLabel { get; set; }
        [Required]
        public string ProductDescription { get; set; }
        public string SKU { get; set; }
        [Required]
        public decimal ProductUnitaryPrice { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime LastUpdateTime { get; set; }
    }
}
