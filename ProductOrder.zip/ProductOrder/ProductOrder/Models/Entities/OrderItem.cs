﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models.Entities
{
    public partial class OrderItem
    {
        public Guid OrderItemId { get; set; }
        public string OrderItemCode { get; set; }
        public string OrderItemLabel { get; set; }
        public string OrderItemDescription { get; set; }
        public int ItemCount { get; set; }
        public decimal OrderItemUnitaryPrice { get; set; }

    }
}
