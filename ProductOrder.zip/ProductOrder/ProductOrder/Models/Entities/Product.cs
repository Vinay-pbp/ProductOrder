﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models.Entities
{
    public partial class Product
    {
        public string ProductId { get; set; }
        public string ProductCode { get; set; }
        public string ProductLabel { get; set; }
        public string ProductDescription { get; set; }
        public string SKU { get; set; }
        public decimal ProductUnitaryPrice { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime LastUpdateTime { get; set; }
    }
}
