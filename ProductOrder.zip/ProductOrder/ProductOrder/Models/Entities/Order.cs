﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models.Entities
{
    public partial class Order
    {
        public Guid OrderId { get; set; }
        public string OrderCode { get; set; }
        public string OrderLabel { get; set; }
        public bool Status { get; set; }
        public Guid OrderItemId { get; set; }
        public decimal TotalPrice { get; set; }
        public int TotalItems { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime LastUpdateTime { get; set; }

    }
}
