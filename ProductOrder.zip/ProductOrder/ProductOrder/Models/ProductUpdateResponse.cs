﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models
{
    public class ProductUpdateResponse
    {
        public string ProductId { get; set; }
        public string SystemMessage { get; set; }
    }
}
