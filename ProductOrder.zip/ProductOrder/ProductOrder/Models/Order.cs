﻿using ProductOrder.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductOrder.Models
{
    public class Order
    {
        public Guid OrderId { get; set; }
        public string OrderCode { get; set; }
        public string OrderLabel { get; set; }
        public OrderStatus Status { get; set; }
        public List<string> Items { get; set; }
        public decimal  TotalPrice { get; set; }
        public int TotalItems { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime LastUpdateTime { get; set; }

    }
}
