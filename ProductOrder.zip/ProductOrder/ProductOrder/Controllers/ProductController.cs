﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProductOrder.DTO;
using ProductOrder.Interface;
using ProductOrder.Models;

namespace ProductOrder.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        #region "Private Variables"
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<ProductController> _logger;
        /// <summary>
        /// Promo Code Service
        /// </summary>
        private readonly IProductService _productService;
        #endregion "Private Variables"

        #region "Constructor"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="productService"></param>
        public ProductController(ILogger<ProductController> logger, IProductService productService)
        {
            _logger = logger;
            _productService = productService;
        }

        #endregion "Constructor"
        #region "Public Methods"
        [HttpPost]
        [ProducesResponseType(typeof(ProductSaveResponse), 200)]
        public async Task<IActionResult> PostAsync([FromBody] ProductDto productDto)
        {
            _logger.LogInformation("Start for insert Product: " + productDto.ProductCode);
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Invalid request.");

                return BadRequest("Invalid request.");
            }

            _logger.LogInformation("Save Product in DB: " + productDto.ProductCode);
            return Ok(await _productService.SaveProductDetailAsync(productDto).ConfigureAwait(false));

        }

        [HttpGet]
        [ProducesResponseType(typeof(ProductGetResponse), 200)]
        public async Task<IActionResult> GetAllAsync()
        {
            _logger.LogInformation("Start for Get Product: ");

            return Ok(await _productService.GetAllProductAsync().ConfigureAwait(false));

        }

        [HttpPut]
        [ProducesResponseType(typeof(ProductUpdateResponse), 200)]
        public async Task<IActionResult> UpdateAsync(string ProductId, ProductUpdateDto productCodeUpdate)
        {
            _logger.LogInformation("Start for update Product: " + ProductId);

            return Ok(await _productService.UpdateProductAsync(ProductId, productCodeUpdate).ConfigureAwait(false));

        }
        #endregion "Public Methods"

    }
}